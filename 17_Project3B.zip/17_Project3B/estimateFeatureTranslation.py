from interp import interp2
import numpy as np
import cv2


def estimateFeatureTranslation(startX, startY, Ix, Iy, img1, img2):

    window = 30

    u,v = startX,startY
    X,Y = np.meshgrid(np.arange(window),np.arange(window))
    X,Y = X.flatten(),Y.flatten()
    xx = X + startX - np.floor(window/2)
    yy = Y + startY - np.floor(window/2)


    Ix_interp = interp2(Ix,xx, yy)
    Iy_interp = interp2(Iy,xx, yy)
    I_interp = interp2(img1,xx, yy)

    # print(img1.shape)
    # print(Ix.shape)
    
    I=np.vstack((Ix_interp,Iy_interp))
    A=I.dot(I.T)

    for i in range(10):
        xx = X + u - np.floor(window/2)
        yy = Y + v - np.floor(window/2)
        #print(i)
        #print(u,v)

        I2_interp = interp2(img2,xx, yy)
        It = (I2_interp - I_interp).reshape((-1,1))
        # print('Energy: ' + str(np.dot(It.T,It)))
        b=-I.dot(It)
        soln = np.dot(np.linalg.inv(A),b)
        u += soln[0]
        v += soln[1]

        #print(soln[0],soln[1])

    return u,v