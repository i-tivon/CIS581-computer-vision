


import numpy as np
from skimage import transform as tf


def applyGeometricTransformation(startXs, startYs, newXs, newYs, bbox):

    ''' • (INPUT) startXs: N ×F matrix representing the starting X coordinates of all the features in the first frame for
        all the bounding boxes
        • (INPUT) startYs: N ×F matrix representing the starting Y coordinates of all the features in the first frame for
        all the bounding boxes
        • (INPUT) newXs: N ×F matrix representing the second X coordinates of all the features in the first frame for all
        the bounding boxes
        • (INPUT) newYs: N ×F matrix representing the second Y coordinates of all the features in the first frame for all
        the bounding boxes
        • (INPUT) bbox: F ×4×2 matrix representing the four new corners of the bounding box where F is the number of
        detected objects
        • (OUTPUT) Xs: N1×F matrix representing the X coordinates of the remaining features in all the bounding boxes
        after eliminating outliers
        • (OUTPUT) Ys: N1×F matrix representing the Y coordinates of the remaining features in all the bounding boxes
        after eliminating outliers
        • (OUTPUT) newbbox: F ×4×2 the bounding box position after geometric transformation
        In the above function, you should eliminate feature points if the distance from a point to the projection of its corresponding
        point is greater than 4. You can play around with this value.


    '''
    #get number of objects
    F,_,_ = bbox.shape

    #initialize new bbox
    newbbox = np.zeros((F,4,2))
    # Xs = newXs.copy()
    # Ys = newYs.copy()


    #loop through objects
    #distance threshold
    D = 1
    N,F = startXs.shape

    Xs,Ys = newXs.copy(),newYs.copy()

    for o in range(F):

        sX = np.reshape(startXs[:,o], (N,1))
        sY = np.reshape(startYs[:,o], (N,1))
        nX = np.reshape(newXs[:,o], (N,1))
        nY = np.reshape(newYs[:,o], (N,1))

       
        src = np.hstack((sX, sY))
        dst = np.hstack((nX, nY))
       

        #eliminate feature points if the distance from a point to
        # the projection of its corresponding point is greater than 4.
        tform = tf.SimilarityTransform()
        tform.estimate(src, dst)
        #print(src.shape)
        proj = tform(src)

        dist = np.sum(np.square(proj-dst),axis = 1)
        # get Xs, Ys, inliers only


        srcNew = src[(dist<D)]
        dstNEw = dst[(dist<D)]
       
        tform.estimate(srcNew, dstNEw)
       

        #bbox_trans = bbox[o,:].reshape(2,2)
        newbbox[o,:,:] = tform(bbox[o,:,:])
       
        # Xs is getting replaced each time
       
       
        Xs[dist>=D,o] = -1
        Ys[dist>= D, o] = -1

    return Xs, Ys, newbbox