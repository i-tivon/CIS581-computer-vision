
'''
[trackedVideo]=objectTracking(rawVideo)
• (INPUT) rawVideo: The input video containing one or more objects
• (OUTPUT) trackedVideo: The generated output video showing all the tracked features 
(please do try to show the trajectories for all the features) 
on the object as well as the bounding boxes
'''
import cv2
import numpy as np
from PIL import Image
from getFeatures import getFeatures
import matplotlib.pyplot as plt
from estimateAllTranslation import estimateAllTranslation
from applyGeometricTransformation import applyGeometricTransformation
# a = np.array([[1,2,3,4],[5,6,7,8]])
# a[0,0:2]+[a[0,2],0]


def objectTracking(rawVideo):
   
    success, old_frame = rawVideo.read()
    #gray scale
    old_gray = cv2.cvtColor(old_frame, cv2.COLOR_BGR2GRAY)
    #out = cv2.VideoWriter('medium result.avi',0,cv2.VideoWriter_fourcc('M','J','P','G'),20.0,(old_frame.shape[1],old_frame.shape[0]))
    make_bbox_pts = 1
    run_name = "7"
    
    F = 1 #2 for easy, 1 for medium, number of objects
    bbox = np.zeros((F,4,2))
    if make_bbox_pts:
        plt.imshow(old_gray)
        
        tup = plt.ginput(n=4*F) #choose tl, tr, bl, br
        '''print("tup")
        print(tup)'''
        plt.show()
        print(len(tup))
   
        for f in range(F):
            for l in range (4):
                print(4*f+l)
                bbox[f,l,:] = tup[4*f+l]
                

        bbox = np.array(bbox).astype(float)
        startXs,startYs = getFeatures(old_gray,bbox)

        np.save('intermediate/bbox' + run_name + '.npy',bbox)
        np.save("intermediate/startXs" + run_name + ".npy",startXs)
        np.save("intermediate/startYs" + run_name + ".npy", startYs)

    else:
        startXs,startYs = np.load("intermediate/startXs" + run_name + ".npy"),np.load("intermediate/startYs" + run_name + ".npy")
        bbox = np.load("intermediate/bbox" + run_name + ".npy")

    
   

    for i in range(1,300):
        success, frame = rawVideo.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        [newXs, newYs] = estimateAllTranslation(startXs,startYs,old_gray,gray)
        # print("before geom")
        # print(startXs.shape)
        [startXs,startYs, bbox] = applyGeometricTransformation(startXs, startYs, newXs, newYs, bbox)
        # print('after geom')
        # print(startXs.shape)

        # update feature points as required
        n_features_left = np.sum(startXs!=-1)
        print('# of Features: %d'%n_features_left)
        if n_features_left < 15:
            print('New Features')
            startXs,startYs = getFeatures(gray,bbox)

        #visualization
        temp = frame.copy()
        #(xmin, ymin, xmax, ymax) = cv2.boundingRect(bbox.astype(int))
        print(bbox.shape)
        for f in range (F): #num of objects
            (xmin, ymin), (xmax, ymax) = (bbox[f,0]).astype(int),(bbox[f,3]).astype(int)

            # print((xmin, ymin), (xmax, ymax))
            # print("hi")
            # print(temp.shape)

            temp = cv2.rectangle(temp, (xmin,ymin), (xmax,ymax), (255,0,0), 2)
            N,_ = startXs.shape
            for g in range(N):
                temp = cv2.circle(temp, (int(startXs[g,f]),int(startYs[g,f])),3,(0,0,255),thickness=2)
       
        
        cv2.imshow('frame',temp)
        out.write(temp) 
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

        old_gray = gray.copy()
        old_frame = frame.copy()
     
    cv2.destroyAllWindows()
    rawVideo.release()
    out.release()

    


    return out


if __name__ == "__main__":
    cap = cv2.VideoCapture('Easy.mp4')
    [trackedVideo]=objectTracking(cap)
    cap.release()