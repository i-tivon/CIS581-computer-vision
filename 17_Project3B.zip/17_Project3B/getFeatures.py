import cv2
import numpy as np
import matplotlib.pyplot as plt
def getFeatures(img,bbox):
    
    F = (bbox.shape)[0]
    bbox = np.int32(bbox)
    N = 50
    x,y = np.zeros((N,F)),np.zeros((N,F))
    for f in range(F):
        (xmin, ymin, w, h) = cv2.boundingRect(bbox[f,:,:].astype(int))
        print( (xmin, ymin, w, h))
       
        


        corners = np.squeeze(np.float32(cv2.goodFeaturesToTrack(img[ymin:ymin+h,xmin:xmin+w],N,0.01,1)))
        cns = len(corners)

 
       
        x[:cns,f] = np.squeeze((corners[:,0]).reshape((cns,1)) + xmin*np.ones((cns,1)))
        y[:cns,f] = np.squeeze(corners[:,1].reshape((cns,1)) + ymin*np.ones((cns,1)))

        # plt.imshow(img[i:ii,j:jj])
        # plt.scatter(corners[:,0],corners[:,1])
        # plt.show()

    return x,y