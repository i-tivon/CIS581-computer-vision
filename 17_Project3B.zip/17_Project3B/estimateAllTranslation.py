import numpy as np
import cv2
from scipy import signal

from getFeatures import getFeatures
from estimateFeatureTranslation import estimateFeatureTranslation
def estimateAllTranslation(startXs,startYs,img1,img2):

    N,F = startXs.shape

    # # TO DO: Compute Gradients
    # Ix = None
    # Iy = None

    newXs,newYs = (-1*np.ones((N,F))).astype(float),(-1*np.ones((N,F))).astype(float)

    # Ix = cv2.Sobel(img1, cv2.CV_64F, 1, 0, ksize=5)
    # Iy = cv2.Sobel(img1, cv2.CV_64F, 0, 1, ksize=5)
    
  
    I = cv2.GaussianBlur(img1, (5, 5), 0.2)

    Iy, Ix = np.gradient(I.astype(float))

    for f in range(F):
        print(f)
        for n in range(N):
            print(n)
            if startXs[n,f] != -1:
                print(startXs[n,f],startYs[n,f])
                newXs[n,f],newYs[n,f] = estimateFeatureTranslation(startXs[n,f],startYs[n,f],Ix,Iy,img1,img2)

    return newXs,newYs