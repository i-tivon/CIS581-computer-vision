READ ME
To run the code with the images I used
Run test.py from the folder
If you wish to select your own points, change select to be = to 1 in line 15
To use, resize input images to be 256x256 (like in test.py)
