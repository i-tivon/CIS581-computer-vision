'''
  File name: click_correspondences.py
  Author: 
  Date created: 
'''

'''
  File clarification:
    Click correspondences between two images
    - Input im1: target image
    - Input im2: source image
    - Output im1_pts: correspondences coordiantes in the target image
    - Output im2_pts: correspondences coordiantes in the source image
'''
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
def click_correspondences(im1, im2):
  '''
    Tips:
      - use 'matplotlib.pyplot.subplot' to create a figure that shows the source and target image together
      - add arguments in the 'imshow' function for better image view
      - use function 'ginput' and click correspondences in two images in turn
      - please check the 'ginput' function documentation carefully
        + determine the number of correspondences by yourself which is the argument of 'ginput' function
        + when using ginput, left click represents selection, right click represents removing the last click
        + click points in two images in turn and once you finish it, the function is supposed to 
          return a NumPy array contains correspondences position in two images
  '''


  fig = plt.figure()
  plt.title("Alternate between clicking on corresponding points in img1 and img 2, 30pts each")
  ax1 = fig.add_subplot(2,2,1)
  ax1.imshow(im1)
  ax2 = fig.add_subplot(2,2,2)
  ax2.imshow(im2)
  N=60
  x = plt.ginput(N, timeout = 0)
  plt.show()
  listOdd = x[1::2] # Elements from list1 starting from 1 iterating by 2
  listEven = x[::2] # Elements from list1 starting from 0 iterating by 2
  im1_pts = np.reshape(listEven,(int(N/2),2))
  im2_pts = np.reshape(listOdd,(int(N/2),2))
  #append corners
  h,w,_ = im1.shape
  c1 = np.array([0,0])
  c2 = np.array([h-1,0])
  c3 = np.array([0,w-1])
  c4 = np.array([h-1,w-1])
  c5 = np.array([h-1,(w-1)/2])
  c6 = np.array([(h-1)/2,0])
  c7 = np.array([0,(w-1)/2])
  c8 = np.array([(h-1)/2,w-1])
  im1_pts=np.vstack((im1_pts,c1))
  im2_pts=np.vstack((im2_pts,c1))
  im1_pts=np.vstack((im1_pts,c2))
  im2_pts=np.vstack((im2_pts,c2))
  im1_pts=np.vstack((im1_pts,c3))
  im2_pts=np.vstack((im2_pts,c3))
  im1_pts=np.vstack((im1_pts,c4))
  im2_pts=np.vstack((im2_pts,c4))
  im1_pts=np.vstack((im1_pts,c5))
  im2_pts=np.vstack((im2_pts,c5))
  im1_pts=np.vstack((im1_pts,c6))
  im2_pts=np.vstack((im2_pts,c6))
  im1_pts=np.vstack((im1_pts,c7))
  im2_pts=np.vstack((im2_pts,c7))
  im1_pts=np.vstack((im1_pts,c8))
  im2_pts=np.vstack((im2_pts,c8))
  return im1_pts, im2_pts
