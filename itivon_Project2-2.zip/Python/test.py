import numpy as np
import matplotlib.pyplot as plt
from PIL import Image




im1 = np.array(Image.open('Me.jpg').convert('RGB'))
im2 = np.array(Image.open('Alice.jpg').convert('RGB'))
h,w,_ = im2.shape

#make images same size
im1 = np.array(Image.fromarray(im1).resize((256,256)))
im2 = np.array(Image.fromarray(im2).resize((256,256)))
select = 1

from click_correspondences import click_correspondences
if select:
    im1_pts, im2_pts = click_correspondences(im1, im2)
    np.save('im1_pts', im1_pts)
    np.save('im2_pts', im2_pts)
else: 
    im1_pts = np.load('im1_pts.npy')
    im2_pts = np.load('im2_pts.npy')

warp_frac = np.linspace(0, 1.0, num=60)
dissolve_frac = np.linspace(0, 1.0, num=60)

from morph_tri import morph_tri
morphed_im = morph_tri(im1, im2, im1_pts, im2_pts, warp_frac, dissolve_frac)

from imageio import mimsave
mimsave('morph.gif',morphed_im,fps=20)


fig = plt.figure()
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(im1)
ax3 = fig.add_subplot(2,2,2)
ax3.imshow(morphed_im[59,:])
ax2 = fig.add_subplot(2,2,3)
ax2.imshow(im2)
plt.show()

