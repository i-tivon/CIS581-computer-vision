'''
  File name: morph_tri.py
  Author:
  Date created:
'''

'''
  File clarification:
    Image morphing via Triangulation
    - Input im1: target image
    - Input im2: source image
    - Input im1_pts: correspondences coordiantes in the target image
    - Input im2_pts: correspondences coordiantes in the source image
    - Input warp_frac: a vector contains warping parameters
    - Input dissolve_frac: a vector contains cross dissolve parameters

    - Output morphed_im: a set of morphed images obtained from different warp and dissolve parameters.
                         The size should be [number of images, image height, image Width, color channel number]
'''
from scipy.spatial import Delaunay
import numpy as np
# from interp import interp2

def morph_tri(im1, im2, im1_pts, im2_pts, warp_frac, dissolve_frac):
  

    N = len(warp_frac)
    h,w,_ = im2.shape
    morphed_im = np.zeros((N,h,w,3))
    im1Warp = np.zeros((N,h,w,3))
    im2Warp = np.zeros((N,h,w,3))
    for n in range(N):
        imd = warp_frac[n]*im2_pts+(1-warp_frac[n])*im1_pts
        Tri = Delaunay(imd)
        wt = np.zeros((h,w))
        for x in range(w):
            for y in range(h):
                wt[y,x] = Tri.find_simplex(np.array([y,x]))

        for t in range(len(Tri.simplices)): #loop through each triangle
            TriangleCorners = imd[Tri.simplices[t]] #3 x 2
            TriangleCorners = np.transpose(TriangleCorners) #2x3

            pts = np.where(wt == t) #find points in that triangle
            xs, ys = pts[0].astype(int), pts[1].astype(int)

            b = np.vstack((xs, ys, np.ones((len(xs)))))
 

            Aimd = np.vstack((TriangleCorners,np.array([1,1,1]))) #3x3
            Aimdinv = np.linalg.inv(Aimd) #get invers

            bc = np.dot(Aimdinv,b) # get Barycentric coordinates

            TriangleCorners1 = im1_pts[Tri.simplices[t]] #3 x 2
            TriangleCorners1 = np.transpose(TriangleCorners1) #2x3
            TriangleCorners2 = im2_pts[Tri.simplices[t]] #3 x 2
            TriangleCorners2 = np.transpose(TriangleCorners2) #2x3
            A1 = np.vstack((TriangleCorners1,np.array([1,1,1]))) #3x3 
            A2 = np.vstack((TriangleCorners2,np.array([1,1,1]))) #3x3

            # find x and y of img 1 and 2
            
            new1 = np.dot(A1, bc)
            new2= np.dot(A2, bc)

            u = h-1
            v = w-1

            x1 = np.clip(np.floor(new1[0]).astype(int),0, v)
            y1 = np.clip(np.floor(new1[1]).astype(int),0, u)
            x2 = np.clip(np.floor(new2[0]).astype(int),0, v)
            y2 = np.clip(np.floor(new2[1]).astype(int),0, u)

    

            im1Warp[n,ys,xs,:] = im1[y1, x1,:] 
            im2Warp[n,ys,xs,:] = im2[y2, x2,:] 
            
        



        d = dissolve_frac[n]

        morphed_im[n] = (((1-d) * im1Warp[n]) + ((d)*im2Warp[n] ))# / 255
    return morphed_im.astype(int)






