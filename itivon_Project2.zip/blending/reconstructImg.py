'''
  File name: reconstructImg.py
  Author:
  Date created:
'''



import numpy as np
from copy import deepcopy
def reconstructImg(indexes, red, green, blue, targetImg):
#  [resultImg] = reconstructImg(indexes, red, green, blue, targetImg)
#  (INPUT) indexes: h0w0 matrix representing the indices of each replacement pixel.
#  (INPUT) red: 1N vector representing the intensity of the red channel replacement pixel.
#  (INPUT) green: 1N vector representing the intensity of the green channel replacement pixel.
#  (INPUT) blue: 1N vector representing the intensity of the blue channel replacement pixel.
#  (INPUT) targetImg: h0w03 matrix representing the target image.
#  (OUTPUT) resultImg: h0w03 matrix representing the resulting cloned image.

  resultImg = deepcopy(targetImg)
  
  for c in range(1,indexes.max()+1):
    h = np.where(indexes == c) 
    h= [h[0][0],h[1][0]]
    r = max(0, min(red[c-1], 255))
    g = max(0, min(green[c-1], 255))
    b = max(0, min(blue[c-1], 255))
    resultImg[h[0]][h[1]] = [r,g,b]

  return resultImg