# from createMask import main
# main('1_source.jpg')
import numpy as np
import matplotlib.pyplot as plt
import os
from scipy import signal
from PIL import Image

from getIndexes import getIndexes
from maskImage import maskImage
#following code is for minion and ben franklin
source = np.array(Image.open('1_source.jpg').convert('RGB'))
maskImage(source, '1')
mask = np.array(Image.open('1_mask.png').convert('L').convert('1'))
target = np.array(Image.open('1_background.jpg').convert('RGB'))
[targetH, targetW,_] = target.shape
l,w,_ = target.shape
offsetX = int(w/2)
offsetY = int(l/2)
#following code is for second set of images
# source = np.array(Image.open('2_source.jpg').convert('RGB'))
# maskImage(source, '2')
# mask = np.array(Image.open('2_mask.png').convert('L').convert('1'))
# target = np.array(Image.open('2_background.jpg').convert('RGB'))
# [targetH, targetW,_] = target.shape
# offsetX = 317
# offsetY = 60

from seamlessCloningPoisson import seamlessCloningPoisson
final = seamlessCloningPoisson(source, target, mask, offsetX, offsetY)
plt.imshow(final)
plt.show()
