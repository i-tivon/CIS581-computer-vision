'''
  File name: getSolutionVect.py
  Author:
  Date created:
'''
 


import numpy as np
from scipy import signal
def getSolutionVect(indexes, source, target, offsetX, offsetY):
#  (INPUT) indexes: h0w0 matrix representing the indices of each replacement pixel.
#  (INPUT) source: hw matrix representing one color channel of the source image.
#  (INPUT) target: h0w0 matrix representing one color channel of target image.
#  (INPUT) offsetX: The x-axis offset of the source image with respect to the target image.
#  (INPUT) offsetY: The y-axis offset of the source image with respect to the target image.
#  (OUTPUT) solVectorb: 1N vector representing the solution vector.
#  generate the solution vector b in the linear system Ax = b.
  SolVectorb = np.zeros(indexes.max(), dtype=int)
  #get laplacian of the source
  #create laplacian
  l =  [[0, -1, 0], [-1, 4, -1], [0 ,-1, 0]]
  G = signal.convolve(source, l, mode ='same', method='auto')
  for c in range(1,indexes.max()+1):
    h = np.where(indexes == c) 
    h= [h[0][0],h[1][0]]
    SolVectorb[c-1] = G[h[0]-offsetY][h[1]-offsetX]

    #boundary pixels of target image
    #check up
    N = np.count_nonzero(indexes)
    if (h[0] > 0):
      if (indexes[h[0]-1][h[1]] == 0) :

        SolVectorb[c-1] = SolVectorb[c-1] + target[h[0]-1][h[1]]
    #left
    if (h[1] > 0):
      if (indexes[h[0]][h[1]-1] == 0) :
        SolVectorb[c-1] = SolVectorb[c-1] + target[h[0]][h[1]-1]
    #right
    if (h[1] < N-1):
      if (indexes[h[0]][h[1]+1] == 0) :
        SolVectorb[c-1] = SolVectorb[c-1] + target[h[0]][h[1]+1]
    #down
    if(h[0] > N-1):
      if (indexes[h[0]+1][h[1]] == 0) :
        SolVectorb[c-1] = SolVectorb[c-1] + target[h[0]+1][h[1]]

  return SolVectorb
