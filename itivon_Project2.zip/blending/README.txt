Project 1b CIS581 
README

Download itivon_Project2.zip

In terminal, enter into folder

If running the given minion and ben Franklin images:
Simply write in terminal: python3 test.py

To run with the images I chose:
(I already made the mask)
Comment out the code below:
‘#following code is for minion and ben franklin’
And uncomment the code below:
‘#following code is for second set of images’

And run ‘python3 test.py’