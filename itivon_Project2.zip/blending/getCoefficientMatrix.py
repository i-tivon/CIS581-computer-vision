'''
  File name: getCoefficientMatrix.py
  Author:
  Date created:
'''


from scipy import sparse
import numpy as np
from scipy import signal
def getCoefficientMatrix(indexes):
  # (INPUT) indexes: h0w0 matrix representing the indices of each replacement pixel.
  # OUTPUT) coeffA: an N N sparse matrix representing the Coefficient Matrix, where N is the
  # number of replacement pixels.
  N = np.count_nonzero(indexes)
  A = sparse.lil_matrix((N, N))


  for c in range(1,N+1):
    h = np.where(indexes == c) 
    h= [h[0][0],h[1][0]]
    A[c-1,c-1] = 4
    #check neighbors
    #up
    if (h[0] > 0):
      b = indexes[h[0]-1][h[1]]
      if(b != 0):
        A[c-1,b-1] = -1
    #down
    if (h[0] < N-1):
      b = indexes[h[0]+1][h[1]]
      if(b != 0):
        A[c-1,b-1] = -1
    #left
    if (h[1] > 0):
      b = indexes[h[0]][h[1]-1]
      if(b != 0):
        A[c-1,b-1] = -1
    #right
    if (h[1] < N-1):
      b = indexes[h[0]][h[1]+1]
      if(b != 0):
        A[c-1,b-1] = -1
    
    
  coeffA = A
  return coeffA
