'''
  File name: seamlessCloningPoisson.py
  Author:
  Date created:
'''

from getIndexes import getIndexes
from getCoefficientMatrix import getCoefficientMatrix
from getSolutionVect import getSolutionVect
from reconstructImg import reconstructImg
from scipy.sparse.linalg.dsolve import linsolve
import numpy as np
import matplotlib.pyplot as plt
from scipy.sparse import csr_matrix


def seamlessCloningPoisson(sourceImg, targetImg, mask, offsetX, offsetY):
# [resultImg] = seamlessCloningPoisson(sourceImg, targetImg, mask, offsetX, offsetY)
#  (INPUT) sourceImg: hw3 matrix representing the source image.
#  (INPUT) targetImg: h0w03 matrix representing the target image.
#  (INPUT) mask: The logical matrix hw representing the replacement region.
#  (INPUT) offsetX: The x-axis offset of the source image with respect to the target image.
#  (INPUT) offsetY: The y-axis offset of the source image with respect to the target image.
#  (OUTPUT) resultImg: h0w03 matrix representing the resulting cloned image.
# call getIndexes.m, getCoefficientMatrix.m,
# getSolutionVect.m and reconstructImg.m and solve the linear system
  [targetH, targetW,_] = targetImg.shape
  index = getIndexes(mask, targetH, targetW, offsetX, offsetY)
  A = getCoefficientMatrix(index)

  bRed = getSolutionVect(index, sourceImg[:,:,0], targetImg[:,:,0], offsetX, offsetY)
  bGreen = getSolutionVect(index, sourceImg[:,:,1], targetImg[:,:,1], offsetX, offsetY)
  bBlue = getSolutionVect(index, sourceImg[:,:,2], targetImg[:,:,2], offsetX, offsetY)


  red = linsolve.spsolve(csr_matrix(A), bRed)

  green = linsolve.spsolve(csr_matrix(A), bGreen)

  blue= linsolve.spsolve(csr_matrix(A), bBlue)

  resultImg = reconstructImg(index, red, green, blue, targetImg)
  xmax, xmin = resultImg.max(), resultImg.min()
  resultImg = (resultImg - xmin)/(xmax - xmin)
  return resultImg