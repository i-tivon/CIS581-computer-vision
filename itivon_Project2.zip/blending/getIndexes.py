'''
  File name: getIndexes.py
  Author:
  Date created:
'''



import numpy as np
def getIndexes(mask, targetH, targetW, offsetX, offsetY):
  #  (INPUT) mask: The logical matrix hw representing the replacement region.
  #  (INPUT) targetH: The height of the target image, h0
  #  (INPUT) targetW: The width of the target image, w0
  #  (INPUT) offsetX: The x-axis offset of the source image with respect to the target image.
  #  (INPUT) offsetY: The y-axis offset of the source image with respect to the target image.
  #  (OUTPUT) indexes: h0w0 matrix representing the indices of each replacement pixel. The value
  # 0 means that is not a replacement pixel.
  [maskI,maskJ] = mask.shape
  indexes = np.zeros((targetH,targetW), dtype=int)
  count  = 1
  for i in range(maskI):
    for j in range(maskJ):
  
      if (mask[i,j] == 1):
        indexes[int(offsetY+i)][int(offsetX+j)] = int(count)
        count=count+1
  
  return indexes