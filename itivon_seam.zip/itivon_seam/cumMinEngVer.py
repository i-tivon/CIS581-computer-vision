'''
  File name: cumMinEngVer.py
  Author:
  Date created:
'''

'''
  File clarification:
    Computes the cumulative minimum energy over the vertical seam directions.
    
    - INPUT e: n × m matrix representing the energy map.
    - OUTPUT Mx: n × m matrix representing the cumulative minimum energy map along vertical direction.
    - OUTPUT Tbx: n × m matrix representing the backtrack table along vertical direction.
'''
import numpy as np
def cumMinEngVer(e):
  n,m = e.shape
  #initialize My, which is the value matrix
  Mx = e.copy()
  #initialize Tby, which is the path matrix
  Tbx = np.zeros((n,m)).astype(int)

  #go row by row
  #start from second row
  for x in range(1,n):
    #ignore border
    for y in range(m):
      #find parent
      #edge case
      if y == 0:
          idx = np.argmin(Mx[x - 1, y:y + 2])
          Tbx[x, y] = idx
          min_energy = Mx[x - 1, idx + y]
      else:

        idx = np.argmin(Mx[x-1, y-1:y+2])
        #fill in value matrix
        min_energy = Mx[x - 1, idx + y - 1]
        
        #update path
        Tbx[x, y] = idx - 1 

      Mx[x, y] += min_energy
                
  return Mx, Tbx