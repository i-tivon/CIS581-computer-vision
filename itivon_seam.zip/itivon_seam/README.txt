READ ME

Inbar Tivon
CIS581
Project 2, Part B: Seam Carving

Open up file itivon_seam.zip
Use test.py to run code
	You can change it to any picture in line 5

To create a gif
	uncomment line 103 in carv.py
	it uses the function in helper.py
To make the gif a new name, change line 20 in helper.py

