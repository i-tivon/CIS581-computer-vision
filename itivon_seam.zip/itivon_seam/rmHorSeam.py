'''
  File name: rmHorSeam.py
  Author:
  Date created:
'''

'''
  File clarification:
    Removes horizontal seams. You should identify the pixel from My from which 
    you should begin backtracking in order to identify pixels for removal, and 
    remove those pixels from the input image. 
    
    - INPUT I: n × m × 3 matrix representing the input image.
    - INPUT My: n × m matrix representing the cumulative minimum energy map along horizontal direction.
    - INPUT Tby: n × m matrix representing the backtrack table along horizontal direction.
    - OUTPUT Iy: (n − 1) × m × 3 matrix representing the image with the row removed.
    - OUTPUT E: the cost of seam removal.
'''
import numpy as np
from rmVerSeam import rmVerSeam
def rmHorSeam(I, My, Tby):
  # #get image shape
  n, m, _ = I.shape

  # # Create a 'True' mask, fill in false pixels later (to take out)
  # mask = np.ones((n, m), dtype=np.bool)

  # # identify the pixel from My from which you should begin backtracking
  # #from final column, find the right row
  # y = np.argmin(My[:,-1])
  # E = My[y,-1]

  # #go from last col to first col
  # for x in reversed(range(m)):
  #     # Mark the pixels for deletion
  #     mask[y, x] = False
  #     #update column based on parents
  #     y = Tby[y, x] + y

  # # Make mask 3D
  # mask = np.stack([mask] * 3, axis=2)

  # # Delete pixels based on mask
  # # and resize it to the new image dimensions
  # Iy = I[mask].reshape((n-1, m, 3)) 
  I = np.transpose(I, (1, 0, 2))
  if(I.shape != (m,n,3)):
    print("A here")
    print([m,n,3])
    print(I.shape)
  Mx = np.transpose(My)
  if(Mx.shape != (m,n)):
    print("B here")
  Tbx = np.transpose(Tby)
  if(Tbx.shape != (m,n)):
    print("C here")
  Ix, E = rmVerSeam(I, Mx, Tbx)
  if Ix.shape == (n-1,m):
    print("change here!")
  Iy = np.transpose(Ix, (1, 0, 2))
  if Iy.shape != (n-1,m,3):
    print(Iy.shape)
    print(n-1,m)
    print("error here!")
  return Iy, E
