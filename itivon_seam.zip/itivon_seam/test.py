import numpy as np
from carv import carv
from PIL import Image
import matplotlib.pyplot as plt
im1 = np.array(Image.open('fish.jpg').convert('RGB'))
# im1 = np.array([[0,0,0,0,0,0],[1,1,0,0,0,0],[1,1,0,0,1,1],
# [1,1,0,0,1,1],[0,0,0,0,1,1,],[0,0,0,0,1,1,]])
# im1 = np.stack([im1] * 3, axis=2)
nr = 20
nc = 20
# print(im1.shape)
Ic, T = carv(im1, nr, nc)
# print(Ic.shape) #(n − nr) × (m − nc) × 3
# print(T.shape) #(nr + 1) × (nc + 1)
plt.imshow(Ic)
plt.show()
