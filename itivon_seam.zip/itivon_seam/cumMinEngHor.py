'''
  File name: cumMinEngHor.py
  Author:
  Date created:
'''

'''
  File clarification:
    Computes the cumulative minimum energy over the horizontal seam directions.
    
    - INPUT e: n × m matrix representing the energy map.
    - OUTPUT My: n × m matrix representing the cumulative minimum energy map along horizontal direction.
    - OUTPUT Tby: n × m matrix representing the backtrack table along horizontal direction.
'''
import numpy as np
from cumMinEngVer import cumMinEngVer
def cumMinEngHor(e):
  # n,m = e.shape
  # #initialize My, which is the value matrix
  # My = e.copy()
  # #first column is same column as energy matrix
  # #initialize Tby, which is the path matrix
  # Tby = np.zeros((n,m)).astype(int)

  # #find 
  # #go column by column 
  # #start from second column
  # for y in range(1,m):
  #   for x in range(n):
  #     if x == 0:
  #         idx = np.argmin(My[x:x + 2, y-1])
  #         Tby[x, y] = idx
  #         min_energy = My[idx+x, y-1]
  #     else:
  #       #find parent
  #       idx = np.argmin(My[x - 1:x + 2, y-1])
  #       #fill in value matrix
  #       min_energy = My[idx+x-1, y-1]
        
  #       #update path eith -1,0,1
  #       Tby[x, y] = idx - 1

  #     My[x, y] += min_energy
     
  My, Tby = cumMinEngVer(np.transpose(e))
  My = np.transpose(My)
  Tby = np.transpose(Tby)
  return My, Tby