'''
  File name: rmVerSeam.py
  Author:
  Date created:
'''

'''
  File clarification:
    Removes vertical seams. You should identify the pixel from My from which 
    you should begin backtracking in order to identify pixels for removal, and 
    remove those pixels from the input image. 
    
    - INPUT I: n × m × 3 matrix representing the input image.
    - INPUT Mx: n × m matrix representing the cumulative minimum energy map along vertical direction.
    - INPUT Tbx: n × m matrix representing the backtrack table along vertical direction.
    - OUTPUT Ix: n × (m - 1) × 3 matrix representing the image with the column removed.
    - OUTPUT E: the cost of seam removal.
'''

import numpy as np


def rmVerSeam(I, Mx, Tbx):
  #get image shape
  n, m, _ = I.shape

  # Create a 'True' mask, fill in false pixels later (to take out)
  mask = np.ones((n, m), dtype=np.bool)

  # identify the pixel from My from which you should begin backtracking
  #from final row, find right column
  x = np.argmin(Mx[-1])

  E = Mx[-1,x]

  #go from last row to first row
  for y in reversed(range(n)):
      # Mark the pixels for deletion
      mask[y, x] = False
      #update column based on parents
      x = Tbx[y, x] + x

  # Make mask 3D
  mask = np.stack([mask] * 3, axis=2)

  # Delete pixels based on mask
  # and resize it to the new image dimensions
  Ix = I[mask].reshape((n, m - 1, 3))

  return Ix, E
