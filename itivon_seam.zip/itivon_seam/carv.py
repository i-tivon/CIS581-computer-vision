'''
  File name: carv.py
  Author:
  Date created:
'''

'''
  File clarification:
    Aimed to handle finding seams of minimum energy, and seam removal, the algorithm
    shall tackle resizing images when it may be required to remove more than one seam, 
    sequentially and potentially along different directions.
    
    - INPUT I: n × m × 3 matrix representing the input image.
    - INPUT nr: the numbers of rows to be removed from the image.
    - INPUT nc: the numbers of columns to be removed from the image.
    - OUTPUT Ic: (n − nr) × (m − nc) × 3 matrix representing the carved image.
    - OUTPUT T: (nr + 1) × (nc + 1) matrix representing the transport map.
'''

import numpy as np
from genEngMap import genEngMap
from cumMinEngHor import cumMinEngHor
from cumMinEngVer import cumMinEngVer
from rmVerSeam import rmVerSeam
from rmHorSeam import rmHorSeam
from helper import helper


def carv(I, nr, nc):
  #it is important to consider sequence of deleting rows or cols
  # T keeps track of the min cost to get to a certain image
  # for each image I have to check what the cost would be to remove a ver seam or hor seam
  # (at the same I save the min E in the T table and the corresponding image in TI?)
  # I can go row by row to fill in T or col by col since :
  # min cost of removing r rows and c-1 cols then removing one more col
  # T(r-1;c)+E(sx(I(n-r+1)(m-c))) = T(r;c-1)+E(sy(I(n-r)(m-c+1)))
  #(T(1,1) = min of  T(0,1)+y and T(1,0)+x). 
  #x is vertical seam and y is horz seem. 
  # Choosing a left neighbor corresponds to a vertical seam removal while choosing the top neighbor corresponds
  # to a horizontal seam removal 
  # n,m,_ = I.shape
  T = np.zeros((nr + 1 ,nc + 1))
  #initialized the array as size (nr+1)x(nc+1) with dtype=object
  TI = np.empty([nr+1,nc+1], dtype=object)
  TI[0,0] = I.copy()
  binaryPath = dict()
  #0 is remove vertical seam move right, 1 is hor seam move down
  count = 0
  for r in range(nr+1):
    for c in range(nc+1):
      if r== nr and c ==nc:
        break

      Iz = TI[r,c]
      if np.array_equal(Iz, I):
        T[r,c] = 0
      
      e = genEngMap(Iz)
      #check if edge case
      if c == nc:
        #not able to remove another column
        My, Tby = cumMinEngHor(e)
        Iy, Ey = rmHorSeam(Iz, My, Tby)
        TI[r+1,c] = Iy
        T[r+1,c] = T[r,c] + Ey
        Ex = np.inf
        # print(count)
        count = count +1
      elif r==nr:
        #not able to remove another row
        Mx, Tbx = cumMinEngVer(e)
        Ix, Ex = rmVerSeam(Iz, Mx, Tbx)
        TI[r,c+1] = Ix
        T[r,c+1] = T[r,c] + Ex
        Ey = np.inf
      else: 
        Mx, Tbx = cumMinEngVer(e)
        My, Tby = cumMinEngHor(e)
        #Ix: n × (m - 1) × 3 matrix representing the image with the column removed.
        Ix, Ex = rmVerSeam(Iz, Mx, Tbx)
        Iy, Ey = rmHorSeam(Iz, My, Tby)
        TI[r+1,c] = Iy
        TI[r,c+1] = Ix
        T[r+1,c] = T[r,c] + Ey
        T[r,c+1] = T[r,c] + Ex

      #check if part of path
      if np.array_equal(Iz, I) or [r,c] in binaryPath.values():
        # print(Ey)
        # print(Ex)
        if c == nc:
          binaryPath[r,c] = [r+1,c]
        elif r ==nr:
          binaryPath[r,c] = [r,c+1]
        elif T[r+1,c] < T[r,c+1] :
          #row removed is better
          # print("correct", count-1)
          binaryPath[r,c] = [r+1,c]
        else:
          binaryPath[r,c] = [r,c+1]
 
  Ic = TI[nr,nc]
  # helper(binaryPath,TI)  
  return Ic, T