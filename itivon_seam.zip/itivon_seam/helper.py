#make the image carving video
def helper(binPath,TI):
    
    Images =[]
    nr,nc = TI.shape
    
    I = TI[0,0]
    Images.append(I)
    r = 0
    c = 0

    while r != nr-1 or c != nc-1:
        IdxNext = binPath[r,c]
        [i,j] = IdxNext
        ImNext = TI[i,j]
        Images.append(ImNext)
        
        r,c = IdxNext
    from imageio import mimsave
    mimsave('carve4.gif',Images,fps=20)


    




