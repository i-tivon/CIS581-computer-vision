#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import torch.nn.functional as F
from mpl_toolkits.mplot3d import Axes3D
import math


# In[9]:


#part 1.1
w = np.linspace(-5,5, num = 20)
b = w

#sigmoid = 1/(1+e^(-wx+b))
def sigmoid(w, b, x):
    return 1/(1+math.exp(-(w*x+b)))
f2 = np.vectorize(sigmoid) 

from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter


# Make data.
X = w
Y = b
X, Y = np.meshgrid(X, Y)
Z = f2(X,Y,np.ones(X.shape))

# # Plot the surface.
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# surf = ax.plot_surface(X, Y, Z, cmap=cm.coolwarm)

# # Customize the z axis.
# ax.set_zlim(0, 1.01)
# ax.zaxis.set_major_locator(LinearLocator(10))
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# # Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)
# plt.title("Sigmoid Activation for Single Input Neuron")

# plt.xlabel("weight")
# plt.ylabel("bias")


# plt.show()


# In[11]:


#part 1.2
y = 0.5*np.ones(X.shape)
x = np.ones(X.shape)

def l2Loss(y,yhat):
    return np.square(yhat - y)
fL = np.vectorize(l2Loss)
Z2 = fL(y, Z)



# # Make data.



# # Plot the surface.
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# surf = ax.plot_surface(X, Y, Z2, cmap=cm.coolwarm)

# # Customize the z axis.
# ax.set_zlim(0, 0.4)
# ax.zaxis.set_major_locator(LinearLocator(10))
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# # Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)
# plt.title("L2 Loss vs weight and bias")

# plt.xlabel("weight")
# plt.ylabel("bias")


# plt.show()


# In[18]:


#part 1.3

# def l2LossGrad(y,yhat,w,b ,x):
#     return 2*(y-yhat)*(1/(1+math.exp(-(w*x+b))) * (1 - (1/(1+math.exp(-(w*x+b))))))
# fLg = np.vectorize(l2LossGrad)
# Z3 = fLg(y,Z,w,b,x)
Z3 = np.array(np.gradient(Z2))


# Plot the surface.
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# surf = ax.plot_surface(X, Y, Z3[0], cmap=cm.coolwarm)

# # Customize the z axis.
# ax.set_zlim(-0.05,0.05)
# ax.zaxis.set_major_locator(LinearLocator(10))
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# # Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)
# plt.title("L2Loss Gradient vs weight and bias")
# plt.xlabel("weight")
# plt.ylabel("bias")

# plt.show()


# In[20]:


#1.4
def LCE(y,yhat):
    return -(y*np.log(yhat)+(1-y)*np.log(1-yhat))
fLce = np.vectorize(LCE)

Z4 = fLce(y, Z)
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# surf = ax.plot_surface(X, Y, Z4, cmap=cm.coolwarm)

# # Customize the z axis.
# ax.set_zlim(-1,5)
# ax.zaxis.set_major_locator(LinearLocator(10))
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# # Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)
# plt.title("Cross-Entropy Loss vs weight and bias")
# plt.xlabel("weight")
# plt.ylabel("bias")

# plt.show()


# In[23]:


#1.5
# def lCELossGrad(y,w,b ,x):
#     return (x*math.exp(b - w*x)*(y - 1))/((1/(math.exp(b - w*x) + 1) - 1)*np.square(math.exp(b - w*x) + 1)) ...
#    ... - (x*y*math.exp(b - w*x))/(math.exp(b - w*x) + 1)
# fcegrad = np.vectorize(lCELossGrad)
# Z5 = fcegrad(y,w,b,x)
Z5 = np.array(np.gradient(Z4))
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# surf = ax.plot_surface(X, Y, Z5[0], cmap=cm.coolwarm)

# # Customize the z axis.
# ax.set_zlim(-0.5,0.5)
# ax.zaxis.set_major_locator(LinearLocator(10))
# ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# # Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)
# plt.title("Cross-Entropy Loss Gradient vs weight and bias")
# plt.xlabel("weight")
# plt.ylabel("bias")

# plt.show()


# In[ ]:




