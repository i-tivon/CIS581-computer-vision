#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import torch.nn.functional as F
from mpl_toolkits.mplot3d import Axes3D
import math
from sklearn.metrics import accuracy_score


# In[2]:


#load data
dimgs = np.load('detection/detection_imgs.npy')
dlabels = np.load('detection/detection_labs.npy')
dwidth = np.load('detection/detection_width.npy')
limgs = np.load('line/line_imgs.npy')
llabels = np.load('line/line_labs.npy')

dimgs = dimgs.reshape([64,1,16,16]).astype(np.float)
dimgs = (torch.from_numpy(dimgs)).float()
dlabels = dlabels.reshape([64,1]).astype(np.float)
dlabels = (torch.from_numpy(dlabels)).float()
dwidth = dwidth.reshape([64,1]).astype(np.float)
dwidth = (torch.from_numpy(dwidth)).float()

limgs = limgs.reshape([64,1,16,16]).astype(np.float)
limgs = (torch.from_numpy(limgs)).float()
llabels = llabels.reshape([64,1]).astype(np.float)
llabels = (torch.from_numpy(llabels)).float()


# In[3]:


class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = torch.nn.Conv2d(1, 16, kernel_size = 7)
        self.conv2 = torch.nn.Conv2d(16, 8, kernel_size = 7)
        self.fc1 = nn.Linear(128,1)
        self.fc2 = nn.Linear(128,1)
        self.fc3 = nn.Linear(1,1)
     
        
        # Define sigmoid activation
        self.sigmoid = nn.Sigmoid()
        
        # Define reLU activation
        self.ReLU = nn.ReLU()

        
    def forward(self, x):
        # Pass the input tensor through each of our operations
        in_size = x.size(0)
        x = self.ReLU(self.conv1(x))
        x = self.ReLU(self.conv2(x))
        x = x.view(in_size,-1)
        yce = self.sigmoid(self.fc1(x))
        yl2 = self.fc3(self.fc2(x))
        return yce,yl2
      
        
      
    
model = Model()


# In[4]:


#make MCE and BCE loss
criterion1 = torch.nn.BCELoss(size_average=True)
criterion2 = torch.nn.MSELoss(size_average=True)


# In[5]:


for m in model.modules():
    if isinstance(m, torch.nn.Linear):
        torch.nn.init.normal(m.weight,mean = 0, std = 0.1)
        torch.nn.init.constant(m.bias,0.1)
    if isinstance(m, torch.nn.Conv2d):
        torch.nn.init.normal(m.weight,mean=0,std=0.1)


# In[6]:


#make optimizers


optimizer = torch.optim.SGD(model.parameters(), lr=0.001)


# In[11]:


#training loop
loss_CE = []
loss_L2 = []
accCE = []
accL2 = []
for epoch in range(10000):
    #forward pass
    yce,wl2 = model(dimgs)
    a = (torch.round(yce) == dlabels).sum() / float(dlabels.size(0))

    accCE.append(a)

    b = abs(wl2 - dwidth) < .5

    bL2 = torch.sum(b) / float(len(dwidth))
    accL2.append(bL2)

    lossce = criterion1(yce, dlabels)
    lossl2 = criterion2(wl2, dwidth)

    loss_CE.append(lossce.data)
    loss_L2.append(lossl2.data)
    
    # combine the total loss as weighed average of two losses

    loss = ((100*lossce) + lossl2) 
    
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    if bL2 == 1.0:
        break


# In[12]:


plt.figure()
plt.plot(loss_CE)
plt.title('CNN for detection data w/Cross Entropy Loss vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('Loss')


plt.figure()
plt.plot(accCE)
plt.title('Accuracy for detection data w/Cross Entropy Loss vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('Accuracy')

plt.figure()
plt.plot(loss_L2)
plt.title('CNN for detection data w/L2 Loss vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('Loss')


plt.figure()
plt.plot(accL2)
plt.title('Accuracy for detection data w/L2 Loss vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('Accuracy')


# In[ ]:


float(accL2[2500])


# In[ ]:




