#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import torch.nn.functional as F
from mpl_toolkits.mplot3d import Axes3D
import math
from sklearn.metrics import accuracy_score


# In[2]:


#load data
dimgs = np.load('detection/detection_imgs.npy')
dlabels = np.load('detection/detection_labs.npy')
dwidth = np.load('detection/detection_width.npy')
limgs = np.load('line/line_imgs.npy')
llabels = np.load('line/line_labs.npy')

dimgs = dimgs.reshape([64,1,16,16]).astype(np.float)
dimgs = (torch.from_numpy(dimgs)).float()
dlabels = dlabels.reshape([64,1]).astype(np.float)
dlabels = (torch.from_numpy(dlabels)).float()
dwidth = dwidth.reshape([64,1]).astype(np.float)
dwidth = (torch.from_numpy(dwidth)).float()

limgs = limgs.reshape([64,1,16,16]).astype(np.float)
limgs = (torch.from_numpy(limgs)).float()
llabels = llabels.reshape([64,1]).astype(np.float)
llabels = (torch.from_numpy(llabels)).float()


# In[3]:


class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = torch.nn.Conv2d(1, 16, kernel_size = 7)
        self.conv2 = torch.nn.Conv2d(16, 8, kernel_size = 7)
        self.fc1 = nn.Linear(128,1)
     
        
        # Define sigmoid activation
        self.sigmoid = nn.Sigmoid()
        
        # Define reLU activation
        self.ReLU = nn.ReLU()

        
    def forward(self, x):
        # Pass the input tensor through each of our operations
        in_size = x.size(0)
        x = self.ReLU(self.conv1(x))
        x = self.ReLU(self.conv2(x))
        x = x.view(in_size,-1)
        x = self.sigmoid(self.fc1(x))
        return x
      
        
      
    
model = Model()


# In[4]:


#make MCE and BCE loss
criterion1 = torch.nn.BCELoss(size_average=True)
criterion2 = torch.nn.MSELoss(size_average=True)


# In[5]:


for m in model.modules():
    if isinstance(m, torch.nn.Linear):
        torch.nn.init.normal(m.weight,mean = 0, std = 0.1)
        torch.nn.init.constant(m.bias,0.1)
    if isinstance(m, torch.nn.Conv2d):
        torch.nn.init.normal(m.weight,mean=0,std=0.1)


# In[6]:


#make optimizers


optimizer = torch.optim.SGD(model.parameters(), lr=0.1)


# In[7]:


#training loop
loss_total = []
acc = []
for epoch in range(10000):
    #forward pass
    ypred = model(limgs)
   
   
    
    #compute loss
    loss = criterion1(ypred, llabels)
   
    
    #zero gradients, backpass, update weights
    
#     optimizer1.zero_grad()
#     loss1.backward()
#     optimizer1.step()
    
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    loss_total.append(loss.data)
    a = (torch.round(ypred) == llabels).sum() / float(llabels.size(0))
   
    acc.append(a)

    
    if a == 1:
        break
        


# In[10]:


loss.type()


# In[8]:


plt.figure()
plt.plot(loss_total)
plt.title('CNN w/ReLU activation vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('Loss')


plt.figure()
plt.plot(acc)
plt.title('Accuracy w/ReLU activation vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('Accuracy')


# In[9]:


len(acc)


# In[ ]:




