#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import torch.nn.functional as F
from mpl_toolkits.mplot3d import Axes3D
import math
from sklearn.metrics import accuracy_score


# In[2]:


#load data
x = np.load('random/random_imgs.npy')
y = np.load('random/random_labs.npy')
imgs = x.reshape([64,16]).astype(np.float)
imgs = (torch.from_numpy(imgs)).float()
labels = y.reshape([64,1]).astype(np.float)
labels = (torch.from_numpy(labels)).float()


# In[3]:


class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.l1 = torch.nn.Linear(16,4)
        self.l2 = torch.nn.Linear(4,1)
        
        
        # Define sigmoid activation
        self.sigmoid = nn.Sigmoid()
        
        # Define reLU activation
        self.ReLU = nn.ReLU()

        
    def forward(self, x):
        # Pass the input tensor through each of our operations
        x = self.l1(x)
        #2.1 2.2
#         x = self.sigmoid(x)
#2.3 2.4
        x = self.ReLU(x)
        x = self.l2(x)
        x = self.sigmoid(x)
      
        
        return x
    
model = Model()


# In[4]:


#make MCE and BCE loss
criterion1 = torch.nn.BCELoss(size_average=True)
criterion2 = torch.nn.MSELoss(size_average=True)


# In[5]:


#make optimizers


optimizer = torch.optim.SGD(model.parameters(), lr=0.1)


# In[6]:


for m in model.modules():
    if isinstance(m, torch.nn.Linear):
        torch.nn.init.normal(m.weight,mean = 0, std = 0.1)
        torch.nn.init.constant(m.bias,0.1)
    if isinstance(m, torch.nn.Conv2d):
        torch.nn.init.normal(m.weight,mean=0,std=0.1)
    


# In[7]:


#training loop
loss_total = []
acc = []
for epoch in range(10000):
    #forward pass
    ypred = model(imgs)
   
    
    #compute loss
    loss = criterion1(ypred, labels)
   
    
    #zero gradients, backpass, update weights
    
#     optimizer1.zero_grad()
#     loss1.backward()
#     optimizer1.step()
    
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    loss_total.append(loss.data)
    a = (torch.round(ypred) == labels).sum() / float(labels.size(0))
   
    acc.append(a)

    
    if a == 1:
        break
acc.pop(0)
acc.pop(0)


# In[8]:


# #2.1 
# plt.figure()
# plt.plot(loss_total)
# plt.title('L2 Loss w/Sigmoid activation vs Training Iterations')
# plt.xlabel('Iterations')
# plt.ylabel('L2 Loss')


# plt.figure()
# plt.plot(acc)
# plt.title('Accuracy w/Sigmoid activation vs Training Iterations')
# plt.xlabel('Iterations')
# plt.ylabel('Accuracy')


# In[9]:


# #2.2
# plt.figure()
# plt.plot(loss_total)
# plt.title('Cross Entropy Loss w/Sigmoid activation vs Training Iterations')
# plt.xlabel('Iterations')
# plt.ylabel('L2 Loss')


# plt.figure()
# plt.plot(acc)
# plt.title('Accuracy w/Sigmoid activation and Cross Entropy Loss vs Training Iterations')
# plt.xlabel('Iterations')
# plt.ylabel('Accuracy')


# In[10]:


# #2.3
# plt.figure()
# plt.plot(loss_total)
# plt.title('L2 Loss w/ReLU activation vs Training Iterations')
# plt.xlabel('Iterations')
# plt.ylabel('L2 Loss')


# plt.figure()
# plt.plot(acc)
# plt.title('Accuracy w/ReLU activation vs Training Iterations')
# plt.xlabel('Iterations')
# plt.ylabel('Accuracy')


# In[14]:


#2.4
plt.figure()
plt.plot(loss_total)
plt.title('Cross Entropy Loss w/ReLU activation vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('L2 Loss')

acc.pop(0)
plt.figure()
plt.plot(acc)
plt.title('Accuracy w/ReLU activation and Cross Entropy Loss vs Training Iterations')
plt.xlabel('Iterations')
plt.ylabel('Accuracy')


# In[ ]:




