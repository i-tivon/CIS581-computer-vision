'''
  File name: findDerivatives.py
  Author:
  Date created:
'''

'''
  File clarification:
    Compute gradient information of the input grayscale image
    - Input I_gray: H x W matrix as image
    - Output Mag: H x W matrix represents the magnitude of derivatives
    - Output Magx: H x W matrix represents the magnitude of derivatives along x-axis
    - Output Magy: H x W matrix represents the magnitude of derivatives along y-axis
    - Output Ori: H x W matrix represents the orientation of derivatives
'''
import numpy as np
import matplotlib.pyplot as plt
import os
from scipy import signal
# from PIL import Image 
import utils, helpers

def findDerivatives(I_gray):
    #create G
    G = utils.GaussianPDF_2D(0, 1, 5, 5)
   

    #filter out noise and compute derivative
    dx, dy = np.gradient(G, axis = (1,0)) 
    Magx = signal.convolve2d(I_gray,dx,'same') 
    Magy = signal.convolve2d(I_gray,dy,'same')

    #compute magnitude of the gradient
    Mag = np.sqrt(Magx*Magx + Magy*Magy)

    #orientation of derivatives. 
    Ori = np.arctan2(Magy, Magx)

    return [Mag, Magx, Magy, Ori]