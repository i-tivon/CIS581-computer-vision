'''
  File name: edgeLink.py
  Author:
  Date created:
'''

'''
  File clarification:
    Use hysteresis to link edges based on high and low magnitude thresholds
    - Input M: H x W logical map after non-max suppression
    - Input Mag: H x W matrix represents the magnitude of gradient
    - Input Ori: H x W matrix represents the orientation of gradient
    - Output E: H x W binary matrix represents the final canny edge detection map
'''
import numpy as np
from interp import interp2
def edgeLink(M, Mag, Ori):
    edge = M * Mag

    #set thresholds
    threshold_low = 0.03*edge.max()
    threshold_high = 0.175*edge.max()

    #make meshgrid
    nr,nc = Mag.shape
    x,y = np.meshgrid(np.arange(nc), np.arange(nr))

    #edges are perpendicular to ori
    OriEdge = np.pi/2 +Ori
    xc = np.cos(OriEdge)
    yc = np.sin(OriEdge)
    linked = np.zeros((nr,nc))
    #get neighbors
    neighb1 = interp2(edge,x +xc, y-yc)
    neighb2 = interp2(edge,x -xc,y +yc)
    #if above high threshold , keep
    a = np.where(edge>=threshold_high)
    linked[a[0],a[1]] = 1
    #if above low threshold and at least one neighbor above high, keep
    h = np.where(np.logical_and(np.logical_or(threshold_high <= neighb1, threshold_high <= neighb2),edge>threshold_low))

    linked[h[0],h[1]] = 1

    #keep connecting?
    c = 50
    while(c > 0):
        neighb1 = interp2(linked,x +xc, y-yc)
        neighb2 = interp2(linked,x -xc,y +yc)
        h = np.where(np.logical_or(1== neighb1, 1== neighb2))

        linked[h[0],h[1]] = 1
        c= c-1



    return linked    
   