'''
  File name: nonMaxSup.py
  Author:
  Date created:
'''

'''
  File clarification:
    Find local maximum edge pixel using NMS along the line of the gradient
    - Input Mag: H x W matrix represents the magnitude of derivatives
    - Input Ori: H x W matrix represents the orientation of derivatives
    - Output M: H x W binary matrix represents the edge map after non-maximum suppression
'''
import numpy as np

def nonMaxSup(Mag, Ori):
    from interp import interp2
    
    nr, nc = Mag.shape
    x,y = np.meshgrid(np.arange(nc), np.arange(nr))
    Z = np.zeros((nr,nc))

    xc = np.cos(Ori)
    yc = np.sin(Ori)


    neighb1 = interp2(Mag,x +xc, y-yc)
    neighb2 = interp2(Mag,x -xc,y +yc)


    h = np.where(np.logical_and(Mag >= neighb1, Mag>= neighb2))
    Z[h[0],h[1]] = 1


    return Z
    
                 
       
    