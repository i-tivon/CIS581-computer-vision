README

Inbar Tivon

CIS581
Project1A

To run code:
Download and unzip itivon_Project1
Note: To use the pictures I chose, change 'folder_name' in line 54 of cannyEdge.py to 'data'.
In terminal, enter project folder: itivon_Project1.

Type in ‘python3 cannyEdge.py’

